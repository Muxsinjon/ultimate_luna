LunaWindow — complete Milestone 1 source and local Git backup

Final commit: aeb54a6a892dedfa96138d008be8170d0382001f
Branch: feat/connecting-ridge-3d

WINDOWS RESTORE
1. Download this ZIP and choose Extract All in Windows File Explorer.
2. Open the extracted LunaWindow-Milestone1 folder.
3. The lunawindow subfolder is the project repository. Its hidden .git folder
   contains the full local history, including commit aeb54a6. Do not delete it.
4. With Git for Windows installed, open PowerShell in that subfolder and run:
      git log -1 --oneline
      git status
      git fsck --full
   Expected HEAD: aeb54a6; branch feat/connecting-ridge-3d; clean working tree.
5. To run the app, install Node.js 22 or newer (Node 24 was validated), then:
      cd web
      npm ci
      npm run dev
6. For optional terrain regeneration, see docs/TERRAIN_3D.md and
   pipeline/requirements-terrain.txt. In a Windows Python virtual environment,
   executables are in .venv\Scripts, rather than .venv/bin.

INCLUDED
All tracked source, configuration, processing scripts, processed terrain and WAC
assets, local fonts/licenses, documentation, tests, full local .git history, and
RECOVERY/lunawindow-milestone1-final.patch. The patch contains both Milestone 1
commits and is an alternative recovery method; do not apply it on top of the
already restored final repository.

EXCLUDED
Reinstallable dependencies/caches, Python environments, original NASA downloads,
rebuildable dist outputs and temporary generated screenshots/results. The real
processed terrain assets needed to run the app ARE included. Raw NASA sources
can be downloaded reproducibly using the checked-in processor.

VERIFY
BACKUP_MANIFEST.json lists SHA-256 hashes for every included project/Git/patch
file. The ZIP also has a separate .sha256 checksum beside the downloadable ZIP.
All archives were CRC-tested; an extracted copy was checked with git fsck,
verified at the exact HEAD above and checked for a clean working tree.

LIMITATIONS
Optional WAC registration remains unverified/off by default. Read
lunawindow/docs/MILESTONE1_ACCEPTANCE.md for final acceptance and limitations.

No source files or remote repositories were modified to create this backup.
