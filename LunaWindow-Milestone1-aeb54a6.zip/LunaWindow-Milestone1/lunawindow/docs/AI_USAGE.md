# AI usage log

This log supports the Space Apps "Use of Super Intelligence (SI)" disclosure.

**Tool:** Claude (Anthropic), used as a coding and research assistant inside Claude Code.

**What the team did:** the team chose the challenge, the concept (terrain-aware Sun/Earth visibility, slip analysis, the validation approach) and the priorities. The AI implemented and debugged code, searched documentation, and drafted docs on request. Every number in the app is computed from NASA data and checked against independent NASA references (`docs/VALIDATION.md`). No AI-generated images, audio or video are used in the app; the favicon and OG image are hand-coded SVG.

| Date (UTC) | Task | Files |
|---|---|---|
| 2026-11-14 | Researched the challenge statement, judging guide, submission guide and five team-supplied YouTube transcripts; drafted the team plan | `PLAN.md` |
| 2026-11-14 | Wrote the Horizons ephemeris fetcher (sub-Earth and sub-solar points in MOON_ME) | `pipeline/fetch_ephemeris.py` |
| 2026-11-14 | Wrote the lunar geometry module and the cross-check against Horizons topocentric az/el | `pipeline/lunar_geom.py`, `pipeline/validate_ephemeris.py` |
| 2026-11-14 | Wrote the LOLA horizon-mask generator and browser DEM export; curated the site list with sources | `pipeline/horizon_mask.py`, `pipeline/sites.py` |
| 2026-11-14 | Compared against the PGDA illumination maps and exported the overlays | `pipeline/validate_illumination.py`, `pipeline/export_overlays.py` |
| 2026-11-14 | Chandrayaan-3 mission check | `pipeline/validate_missions.py` |
| 2026-11-14 | Built the React web app: explorer, sky chart, timeline, metrics, polar map, compare, slip analyzer, method page | `web/src/**` |
| 2026-11-14 | Wrote the README, .gitignore and launch config | `README.md`, `.gitignore`, `.claude/launch.json` |
| 2026-11-14 | Audited the codebase and took before screenshots | `AUDIT.md`, `docs/screenshots/before/*`, `tests/e2e/screenshots.py` |
| 2026-11-14 | Wrote the project rules, design system, quality checklist and this log | `CLAUDE.md`, `docs/DESIGN_SYSTEM.md`, `docs/QUALITY_CHECKLIST.md`, `docs/AI_USAGE.md` |
| 2026-11-14 | Physics refactor: pure functions for disc fraction, upper-limb rise/set, longitude normalization, time windows; 0–360° longitude data contract | `web/src/lib/physics/*`, `web/src/lib/analysis.ts`, `pipeline/horizon_mask.py`, `pipeline/lunar_geom.py` |
| 2026-11-14 | Unit tests (physics, URL state, ephemeris upsampling, Horizons fixture) and the validation report generator | `web/src/lib/**/*.test.ts`, `pipeline/validation_table.py`, `docs/VALIDATION.md` |
| 2026-11-14 | Design tokens and theme ("Terminator"), dark/light, Barlow type; restyled every component | `web/src/styles/*`, `web/src/components/*`, `web/index.html` |
| 2026-11-14 | New UI pieces: header with Planner/Explore and UTC/Local, info tooltips, status chips, Explore explanations, mission-validation panel, onboarding, error boundaries, skeletons | `Header.tsx`, `ui.tsx`, `Metrics.tsx`, `Explain.tsx`, `MissionCheck.tsx`, `Onboarding.tsx`, `glossary.ts` |
| 2026-11-14 | Compare deltas, landing-calendar restyle, data-and-methods page, shareable URL state and keyboard control | `Compare.tsx`, `SlipAnalyzer.tsx`, `About.tsx`, `lib/url.ts`, `App.tsx` |
| 2026-11-14 | Performance: 6-hourly ephemeris upsampled in the browser, lazy terrain, Preact runtime alias, non-blocking fonts; Lighthouse runs | `lib/ephemeris.ts`, `lib/data.ts`, `PolarMap.tsx`, `vite.config.ts`, `docs/lighthouse/*` |
| 2026-11-14 | Brand assets (OG image, favicons), rendered from hand-written SVG with Playwright (not AI-generated imagery) | `pipeline/make_brand_assets.py`, `web/public/*.png`, `web/public/favicon.svg` |
| 2026-11-14 | Repo hygiene: ESLint, Prettier, .gitattributes, CI and Pages workflows, README, LICENSE, dead-code removal | `web/eslint.config.js`, `.github/workflows/*`, `README.md`, `LICENSE` |
| 2026-11-14 | Playwright smoke tests and screenshot capture; after screenshots | `tests/e2e/*`, `docs/screenshots/after/*` |
| 2026-11-14 | Audit, status tracking and quality checklist | `AUDIT.md`, `docs/QUALITY_CHECKLIST.md` |
| 2026-11-14 | Gap analysis of the LunaWindow master prompt vs the build | `docs/LUNAWINDOW_CHECKLIST.md` |
| 2026-11-14 | Visibility models (geometric 0° and terrain-aware), hourly half-open sampled metrics, Mission Window Finder engine and tests | `web/src/lib/visibility.ts`, `web/src/lib/finder.ts`, `web/src/lib/analysis.ts`, `*.test.ts` |
| 2026-11-14 | Shared mission state in the URL with supported-date clamping | `web/src/lib/state.ts`, `web/src/lib/store.tsx`, `web/src/App.tsx` |
| 2026-11-14 | LunaWindow workspaces: welcome, Explore & Compare, Mission Window Finder with Why-this-window, Surface View, guided demo, mission summary export | `web/src/workspaces/*`, `web/src/components/*` |
| 2026-11-14 | Rebrand (title, header, OG image with computed Sun/Earth), README, CLAUDE.md, checklist status | `web/index.html`, `pipeline/make_brand_assets.py`, `README.md`, `CLAUDE.md`, `docs/LUNAWINDOW_CHECKLIST.md` |
| 2026-11-14 | Updated Playwright smoke tests and screenshots for the new workspaces | `tests/e2e/*`, `docs/screenshots/after/*` |
| 2026-11-14 | Performance: prefetch the requested workspace chunk in parallel with data; Lighthouse re-run | `web/src/App.tsx`, `docs/lighthouse/*`, `docs/QUALITY_CHECKLIST.md` |
| 2026-11-14 | Publishing: rewrote commit author, pushed to GitHub, enabled Pages, verified the live site with the smoke tests, added the live link | `README.md`, `docs/QUALITY_CHECKLIST.md`, `docs/LUNAWINDOW_CHECKLIST.md` |
| 2026-11-14 | Continued Milestone 1 after environment replacement: recreated the missing local-only terrain branch, downloaded and verified real NASA PGDA Site01 5 m DEM and RMS uncertainty, implemented curved Three.js terrain and Site A/B point selection, reprojected actual NASA Trek LROC WAC context imagery, added reproducible source processing, real-data tests, browser screenshots and status/PR documentation. No invented elevation or imagery; no GitHub push/PR/merge. | `pipeline/terrain_site01.py`, `pipeline/test_terrain_site01.py`, `pipeline/requirements-terrain.txt`, `web/public/data/terrain/site01/*`, `web/src/lib/terrainMesh*`, `web/src/components/TerrainCanvas.tsx`, `web/src/workspaces/TerrainExplorer.tsx`, `web/src/App.tsx`, `web/src/lib/state.ts`, `web/src/components/Header.tsx`, `web/src/workspaces/SurfaceView.tsx`, `web/src/styles/workspaces.css`, `web/package*.json`, `tests/e2e/terrain_test.py`, `docs/TERRAIN_3D.md`, `docs/PROJECT_STATUS.md`, `docs/PULL_REQUEST_MILESTONE_1.md`, `docs/data/SITE01_README.txt`, `README.md` |

| 2026-11-14 | Final Milestone 1 acceptance: marked optional WAC registration unverified/off by default; safely self-hosted licensed Barlow fonts; independently checked 101 source-coordinate samples and five real browser picks against the original GeoTIFF; reran full tests, smoke checks and screenshots; updated acceptance/status evidence. No Milestone 2 or remote changes. | `web/public/fonts/*`, `web/index.html`, `web/src/workspaces/TerrainExplorer.tsx`, `web/src/lib/terrainMesh.test.ts`, `pipeline/verify_site01_acceptance.py`, `pipeline/test_terrain_site01.py`, `tests/e2e/terrain_test.py`, `docs/data/SITE01_*`, `docs/MILESTONE1_ACCEPTANCE.md`, `docs/PROJECT_STATUS.md`, `docs/TERRAIN_3D.md`, `docs/PULL_REQUEST_MILESTONE_1.md`, `README.md` |
